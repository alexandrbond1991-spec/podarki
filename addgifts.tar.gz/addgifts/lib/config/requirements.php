<?php
return array(
    'app.shop' => array(
        'name' => 'Приложение «Магазин»',
        'description' => '',
        'strict' => true,
        'version' => '>=8.3',
    ),
    'php' => array(
        'strict' => true,
        'version' => '>=5.5',
    ),
);