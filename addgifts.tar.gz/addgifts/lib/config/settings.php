<?php
/**
 * User: Echo-company
 * Email: info@echo-company.ru
 * Site: https://www.echo-company.ru
 */
return array(
    'enable' => '1',
    'gift_price' => '0',
    'price_comment' => 'под подарком подразумевается стоимость в {$common_settings.gift_price}',
    'group_rules' => '0',
    'show_revert' => '1',
    'export' => '1',
    'cart_limit' => '1'
);
