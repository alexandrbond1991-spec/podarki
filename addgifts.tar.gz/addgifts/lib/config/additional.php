<?php
return array(
    'plugin_id' => 'addgifts',
    'doc' => 'https://ss.echo-company.ru/docs/podarki-nastrojka-plagina/',
);
