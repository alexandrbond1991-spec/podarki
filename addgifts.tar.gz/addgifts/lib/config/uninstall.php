<?php
/**
 * Установка переменных по умолчанию
 * (для симметрии с install)
 * User: Echo-company
 * Email: info@echo-company.ru
 * Site: https://www.echo-company.ru
 */