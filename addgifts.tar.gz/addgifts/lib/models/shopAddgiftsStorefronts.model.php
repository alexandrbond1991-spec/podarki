<?php

/**
 * Модель дляработы с настройками витрин
 *
 * User: Echo-company
 * Email: info@echo-company.ru
 * Site: https://www.echo-company.ru
 */
class shopAddgiftsStorefrontsModel extends waModel
{
    protected $table = 'shop_addgifts__storefronts';
}