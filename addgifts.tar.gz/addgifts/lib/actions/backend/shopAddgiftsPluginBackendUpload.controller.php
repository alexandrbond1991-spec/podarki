<?php

/**
 *
 * Удаление правила
 *
 * User: Echo-company
 * Email: info@echo-company.ru
 * Site: https://www.echo-company.ru
 */
class shopAddgiftsPluginBackendUploadController extends waJsonActions
{

    public function execute($action)
    {

    }

}